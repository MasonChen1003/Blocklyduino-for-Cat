  // Battery Voltage
  BatteryVol = analogRead(BatteryPin) * VoltageDevider * 0.1;
//  Batterylabel.updateText("Battery " + String(BatteryVol, 2) + "V");  
//Serial.println(BatteryVol);
if (BatteryVol > BatteryLowVol) { 

  // if there's data available, read a packet
  int packetSize = Udp.parsePacket();
  if ((packetSize) && (busy_status <1)) {
              busy_status = 1; 
  //  Serial.print("Received packet of size ");
 //   Serial.println(packetSize);
 //   Serial.print("From ");
    IPAddress remoteIp = Udp.remoteIP();
//    Serial.print(remoteIp);
 //   Serial.print(", port ");
 //   Serial.println(Udp.remotePort());

    // read the packet into packetBufffer
    int len = Udp.read(packetBuffer, 255);
    if (len > 0) {
      packetBuffer[len] = 0;
    }
    Serial.println("Contents:");
    Serial.println(packetBuffer);
    String receive_data = String(packetBuffer); 

          // Check to see if the client request was "GET /right" or "GET /left":
           if (receive_data.startsWith("F")) {
              Servo_PROGRAM_Run(Motion_data_1, Motion_data_1_Step);
        Servo_PROGRAM_Run(Servo_home, 1);
           }
           if (receive_data.startsWith("B")) {
              Servo_PROGRAM_Run(Motion_data_2, Motion_data_2_Step);
        Servo_PROGRAM_Run(Servo_home, 1);
           }
           if (receive_data.startsWith("L")) {
              Servo_PROGRAM_Run(Motion_data_3, Motion_data_3_Step);
        Servo_PROGRAM_Run(Servo_home, 1);
           }
           if (receive_data.startsWith("S")) {
      //         Servo_PROGRAM_Run(user_data_sit, user_data_sit_Step);
     //        Servo_PROGRAM_Center();
              Servo_PROGRAM_Run(Servo_home, 1);
       //       delay(300);
           }
           if (receive_data.startsWith("R")) {
              Servo_PROGRAM_Run(Motion_data_4, Motion_data_4_Step);
        Servo_PROGRAM_Run(Servo_home, 1);
           }
           if (receive_data.startsWith("U")) {
        Servo_PROGRAM_Run(Motion_data_demo1, Motion_data_demo1_Step);
           }
           if (receive_data.startsWith("D")) {
        Servo_PROGRAM_Run(Servo_home, 1);
           }

    // send a reply, to the IP address and port that sent us the packet we received
    Udp.beginPacket(Udp.remoteIP(), Udp.remotePort());
    Udp.write(ReplyBuffer);
    Udp.endPacket();

    busy_status = 0; 
  }  
 }    // Battery check loop 
