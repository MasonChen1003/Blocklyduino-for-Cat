//////////////////////////////////////////////////////////////////////
// Q-ter Cat (Using MiniPlan TinyPlan97) by Mason E & D (2019.4)
/////////////////////////////////////////////////////////////////////

// Author : Mason 2019/7/30, masonchen1003@gmail.com
// FB : https://www.facebook.com/mason.chen.1420
// Licensed under the Creative Commons - Attribution - Non-Commercial license.
// �дL�����z�]���v�A�p�n�ϥΩ�L�B�����ΡA�е����X�B�γq����@�̡C

#include <Servo.h>
#include <EEPROM.h>

// servo offset, pleaee update the offset values
//                       P2, P5,P13,P10, P4, P7,P12,P11,P17,P16
int offset[] PROGMEM = {  0,  0,  0,  0,  0,  0,  0,  0,  0,  0};  // default
// int offset[] PROGMEM =    {  7, -4, 11,  7, -1, -3, 10,  7,  6,  0};  // example

// Version
String FW_Version = "Q-ter Cat V307 (2019/08/15)";

// Battery
#define BatteryPin  14  
float BatteryVol = 0;
int BatteryCount = 0;
const float BatteryLowVol = 4.65;
const float R1 = 100;     // 10Kohm, The Voltage devider resistor R1
const float R2 = 47;      // 4.7Kohm, The Voltage devider resistor R2
const float Vmax = 6.2;   // Input voltage that would give 2.5V in voltage devider.
const int   VStep = 1024; // Each voltage step in the analog pin will indicate this voltage is given.
float VoltageDivider = 0; // VoltageDivider = (ADC/(R2/(R1+R2)))/1024

// Servos Matrix
const int ALLMATRIX = 11;        // P2 + P5 + P13 + P10 + P4 + P7 + P12 + P11 + P17 + P16 + Run Time
const int ALLSERVOS = 10;        // P2 + P5 + P13 + P10 + P4 + P7 + P12 + P11 + P17 + P16

// SG90 Servo PWM Pulse Traveling
const int PWMRES_Min = 1;       // PWM Resolution 1
const int PWMRES_Max = 180;     // PWM Resolution 180
const int SERVOMIN = 500;       // 500
const int SERVOMAX = 2400;      // 2400

// Servo update time
const int Update_time = 10;   // 10ms

// Backup Servo Value
float Running_Servo_POS [ALLSERVOS];

Servo All_Servo[ALLSERVOS]; 

int tune[] PROGMEM = { 0,0,0,0,0,0,0,0,0,0};  
int motion[] PROGMEM = { 90,90,90,90,90,90,90,90,90,90,500};

int Servo_home [][ALLMATRIX] = { 50,  90,  90,  130,  130,  90,  90,  50, 90 , 90, 500 };
int Servo_init [][ALLMATRIX] = { 90,  90,  90,  90,  90,  90,  90,  90, 90 , 90, 500 };

void Servo_PROGRAM_Run(int iMatrix[][11],  int iSteps) {
  float inter_increment[ALLSERVOS];
  unsigned long target_time;
  unsigned long step_time;
  
  for ( int MainLoopIndex = 0; MainLoopIndex < iSteps; MainLoopIndex++)  
    {
    int run_time = iMatrix [ MainLoopIndex ] [ ALLMATRIX - 1 ];
        for (int i = 0; i < ALLSERVOS; i++) 
          {
            inter_increment[i] = (iMatrix[MainLoopIndex][i] - Running_Servo_POS[i]) / (run_time / Update_time);
          }          
      target_time =  millis() + run_time;

      while (millis() < target_time) {
        step_time = millis() + Update_time;
       // Servo run to step's position
        for (int i = 0; i < ALLSERVOS; i++) 
          {
           All_Servo[i].writeMicroseconds(floor((Running_Servo_POS[i] + inter_increment[i] + tune[i]+offset[i]) / PWMRES_Max * (SERVOMAX - SERVOMIN) + SERVOMIN)); 
           Running_Servo_POS[i] = Running_Servo_POS[i] + inter_increment[i];
          }
       delay(10);
      }
   }   // end of main_loop
}

void Run_PROGRAM_function(int motion_data[][ALLSERVOS],  int motion_step, int step_time) {
       // Servo run to step's position
  for ( int i_loop = 0; i_loop < motion_step; i_loop++)  
    {
         for (int i = 0; i < ALLSERVOS; i++) 
          {
           All_Servo[i].writeMicroseconds(floor(motion_data[i_loop][i] + offset[i]) / PWMRES_Max * (SERVOMAX - SERVOMIN)  + SERVOMIN); 
           }
        delay(step_time);   
    }
}

String splitString(String data, char separator, int index)
{
    int stringData = 0;        //variable to count data part nr 
    String dataPart = "";      //variable to hole the return text
    
    for(int i = 0; i<data.length(); i++) {         
      if(data[i]==separator) {
        //Count the number of times separator character appears in the text
        stringData++;       
      }else if(stringData==index) {
        //get the text when separator is the rignt one
        dataPart.concat(data[i]);       
      }else if(stringData>index) {
        //return text and stop if the next separator appears - to save CPU-time
        return dataPart;
        break;        
      }
    }
    return dataPart;
}
